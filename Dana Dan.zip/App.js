import React,{useState,Component,useEffect} from 'react';
import { Platform,Button, View,StyleSheet,Text,ScrollView,Dimensions,TextInput,TouchableOpacity,Alert } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import Icon from 'react-native-vector-icons/FontAwesome';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import { createMaterialBottomTabNavigator } from '@react-navigation/material-bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import styled from 'react-native-styled-components';
import { Video } from 'expo-av';
import Swiper from 'react-native-swiper';
//These are the Three Login



function HomeScreen({ navigation,route}) {


    const [name,setName] = useState();



    function sendsms(){

        var b = Math.floor(Math.random()*9999)+1111;
        alert(b);

        var otp = "https://2factor.in/API/V1/2526e088-ba2c-11ea-9fa5-0200cd936042/SMS/" + name + "/" + b;

        fetch(otp,{
            method: 'GET',
        }).then((response)=>response.json())
            .then((responseJson)=>{
                Alert.alert(responseJson.Status);
                navigation.navigate('OtpVeri',{otp:b });
            })
            .catch((error) => {
                console.log(error)
            });

    }





    return (
        <View style={{flex:2 }}>

            <View style={styles.con1}> 
                <Icon name="mobile" size={150} color="#ff7675" />

            </View>
            <View style={styles.con2 }>

                <TextInput
                    style={{ height: 50,width:'90%',fontSize:20,borderBottomWidth:1 ,borderColor: 'gray', }}
                    value="India(+91)" editable={false} />


                <TextInput
                    style={{ height: 50,width:'90%',fontSize:20,borderBottomWidth:1 ,borderColor: 'gray', }}
                    placeholder="Phone Number" keyboardType='numeric'  onChangeText={(text)=>{ setName(text);  }} />

                <Text style={{marginTop:20}}>We will send you one time SMS message</Text>

                <TouchableOpacity style={{marginTop:20}} onPress={sendsms}>

                    <Icon name="play" size={50} color="#ff7675" />

                </TouchableOpacity>


            </View>

        </View>
    );
}

function veri({navigation,route}){

    const [otp,setOtp] = useState();
    const [num,setNum] = useState();

    useEffect(()=>{
        var b = route.params?.otp;
        setNum(b);
    },[])

    function checko(){

        if(otp==1234){

            alert("You Enter The Correctly");
            navigation.navigate('root1',{screen:'homi'});

        }
        else
        {
            alert("You Enter The Incorrectly Please Enter The Correctly");

        }

    }

    return(

        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>

            <OTPInputView
                style={{width: '80%',height:150,textShadowColor: '#000000'}}
                pinCount={4}

                codeInputFieldStyle={{borderWidth:2,borderColor:'black',borderRadius:15,color:'black',fontSize:30}}
                codeInputHighlightStyle={{borderWidth:3,borderColor:'red',textShadowColor: '#000000' }}
                keyboardType='numeric'
                onCodeFilled = {(code => {
                    setOtp(code);
                })}
            />

            <TouchableOpacity style={{marginTop:20}} onPress={checko}>

                <Icon name="play" size={50} color="#ff7675" />

            </TouchableOpacity>



        </View>

    );



}

//this is the main home page


function home(){

    const Vid = styled(Video,{
        height:'100%',
        width:'100%',
        position: "absolute",
        top: 0,
        left: 0,
        bottom: 0,
        right:0 ,

    });

    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            {/*This is Slider Menu*/}

            <Swiper style={styles.wrapper} horizontal={false} loop={true}>
                    
                    
                <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
                    <Vid
                        rate={1.0}
                        volume={1.0}
                        isMuted={false}
                        shouldPlay
                        resizeMode='stretch'
                        isLooping
                        source={require('./assets/demo.mp4')}
                    />
                    <View style={styles.bottom}>
                        <Text style={{fontSize:20,fontWeight:'bold',color:'white'}}>@Deepak_Mishra</Text>

                    </View>
                    </View>
                
        {/*This is Second*/}
                
                <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
                    <Vid
                        rate={1.0}
                        volume={1.0}
                        isMuted={false}
                        shouldPlay
                        resizeMode='stretch'
                        isLooping
                        source={{uri:'http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4'}}
                    />
                    <View style={styles.bottom}>
                        <Text style={{fontSize:20,fontWeight:'bold',color:'white'}}>@Test Documents</Text>

                    </View>
                    </View>




            </Swiper>

        </View>
    );
}

function search(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Search</Text>
        </View>
    );

}


function Add(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Adding Videos</Text>
        </View>
    );
}

function profile1(){
    return(
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Profile</Text>
        </View>
    );


}



const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();
const Tab = createMaterialBottomTabNavigator();

function root1(){
    return( 
        <Tab.Navigator
            activeColor="white"
            barStyle={{ height:'10%',width:'100%',backgroundColor: 'black' }}

        >
            <Tab.Screen
                name="home"
                component={home}
                options={{
                    tabBarLabel: 'Home',
                    tabBarIcon: () => (
                        <Icon name="home" size={25} color='#f5f6fa' />
                    ),
                }}
            />

            <Tab.Screen
                name="search"
                component={search}
                options={{
                    tabBarLabel: 'Search',
                    tabBarIcon: () => (
                        <Icon name="search" size={25} color='#f5f6fa' />
                    ),
                }}
            />

            <Tab.Screen
                name="add"
                component={Add}

                options={{
                    tabBarLabel:()=>null,          
                    tabBarIcon: () => (
                        <Icon name="plus-square" size={25} color='red' />
                    ),
                }}
            />

            <Tab.Screen
                name="profile"
                component={profile1}
                options={{
                    tabBarLabel: 'Profile',
                    tabBarIcon: () => (
                        <Icon name="user-o" size={25} color='#f5f6fa' />
                    ),
                }}
            />




        </Tab.Navigator>



    );}



export default function App() {
    return (
        <NavigationContainer>
            <Stack.Navigator initialRouteName="Homo">
                <Stack.Screen name="Homo" options={{headerShown:false}}   component={HomeScreen} />
                <Stack.Screen name="OtpVeri" component={veri} />
                <Stack.Screen options={{headerShown:false}} name="root1" component={root1} />


            </Stack.Navigator>
        </NavigationContainer>
    );
}

const styles = StyleSheet.create({
    container:{
        flex:1,

    },
    con1:{
        flex:0.7,
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'#48dbfb',
        borderBottomRightRadius:60,
        borderBottomLeftRadius:60,

    },
    wrapper:{},
    con2:{ 
        flex:1,
        alignItems:'center',
        marginTop:40,
    },
    bottom:{
        height:30,
        width:'60%',
        justifyContent: 'center',
        alignItems:'center', 
        position:'absolute',
        bottom:40,
        left:0,
    }


});
